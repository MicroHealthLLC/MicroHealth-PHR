
package com.phr.data.output;



/**
 * Generated for query "getCarePlanGraph" on 07/18/2013 21:17:10
 * 
 */
public class GetCarePlanGraphRtnType {

    private String problem;
    private Long occurence;

    public String getProblem() {
        return problem;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }

    public Long getOccurence() {
        return occurence;
    }

    public void setOccurence(Long occurence) {
        this.occurence = occurence;
    }

}
