
package com.phr.data.output;



/**
 * Generated for query "getLabsList" on 07/18/2013 21:17:10
 * 
 */
public class GetLabsListRtnType {

    private String lab;
    private Integer userid;

    public String getLab() {
        return lab;
    }

    public void setLab(String lab) {
        this.lab = lab;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

}
