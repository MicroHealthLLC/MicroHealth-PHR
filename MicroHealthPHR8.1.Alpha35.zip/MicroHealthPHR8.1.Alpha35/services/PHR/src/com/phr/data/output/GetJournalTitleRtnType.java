
package com.phr.data.output;



/**
 * Generated for query "getJournalTitle" on 07/18/2013 21:17:10
 * 
 */
public class GetJournalTitleRtnType {

    private String journal;
    private Integer userid;

    public String getJournal() {
        return journal;
    }

    public void setJournal(String journal) {
        this.journal = journal;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

}
