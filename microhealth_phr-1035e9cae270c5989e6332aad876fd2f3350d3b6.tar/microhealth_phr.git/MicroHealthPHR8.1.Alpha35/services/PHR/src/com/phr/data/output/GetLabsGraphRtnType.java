
package com.phr.data.output;

import java.util.Date;


/**
 * Generated for query "getLabsGraph" on 07/18/2013 21:17:10
 * 
 */
public class GetLabsGraphRtnType {

    private Date date;
    private String labs;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLabs() {
        return labs;
    }

    public void setLabs(String labs) {
        this.labs = labs;
    }

}
