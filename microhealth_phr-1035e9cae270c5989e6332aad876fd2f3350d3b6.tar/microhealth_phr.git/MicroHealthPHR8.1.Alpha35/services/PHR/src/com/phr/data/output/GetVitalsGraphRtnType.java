
package com.phr.data.output;

import java.util.Date;


/**
 * Generated for query "getVitalsGraph" on 07/18/2013 21:17:10
 * 
 */
public class GetVitalsGraphRtnType {

    private Date date;
    private String vitals;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getVitals() {
        return vitals;
    }

    public void setVitals(String vitals) {
        this.vitals = vitals;
    }

}
