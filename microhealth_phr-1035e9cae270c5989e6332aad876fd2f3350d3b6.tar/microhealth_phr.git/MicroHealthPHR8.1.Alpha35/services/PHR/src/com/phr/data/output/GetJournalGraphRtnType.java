
package com.phr.data.output;



/**
 * Generated for query "getJournalGraph" on 07/18/2013 21:17:10
 * 
 */
public class GetJournalGraphRtnType {

    private String journal;
    private Long occurrence;

    public String getJournal() {
        return journal;
    }

    public void setJournal(String journal) {
        this.journal = journal;
    }

    public Long getOccurrence() {
        return occurrence;
    }

    public void setOccurrence(Long occurrence) {
        this.occurrence = occurrence;
    }

}
