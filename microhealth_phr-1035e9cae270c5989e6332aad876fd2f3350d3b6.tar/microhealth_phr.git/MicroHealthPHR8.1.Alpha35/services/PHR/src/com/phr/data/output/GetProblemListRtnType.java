
package com.phr.data.output;



/**
 * Generated for query "getProblemList" on 07/18/2013 21:17:10
 * 
 */
public class GetProblemListRtnType {

    private String problem;
    private Integer userid;

    public String getProblem() {
        return problem;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

}
