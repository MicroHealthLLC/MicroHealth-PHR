
package com.phr.data.output;



/**
 * Generated for query "getMedicationList" on 07/18/2013 21:17:10
 * 
 */
public class GetMedicationListRtnType {

    private String medication;
    private Integer userid;

    public String getMedication() {
        return medication;
    }

    public void setMedication(String medication) {
        this.medication = medication;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

}
