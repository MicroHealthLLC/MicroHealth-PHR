
package com.phr.data.output;



/**
 * Generated for query "getAllergyTitle" on 07/18/2013 21:17:10
 * 
 */
public class GetAllergyTitleRtnType {

    private String allergy;
    private Integer userid;

    public String getAllergy() {
        return allergy;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

}
